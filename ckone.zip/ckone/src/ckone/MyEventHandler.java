package ckone;


public abstract class MyEventHandler implements EventHandler {

	@Override
	public abstract void actionPerformed();
	
}
