package ckone;

public class Launcher {
	
	public static void main(String[] args) {
		
		Button btn = new Button();
		//MyEventHandler meh = new MyEventHandler();
		MyEventHandler2 meh2 = new MyEventHandler2();
		
		//btn.addEventHandler(meh);
		btn.addEventHandler(meh2);
		btn.click();
	}

}
