package ckone;

import java.util.ArrayList;

public class Button {
	
	ArrayList<EventHandler> EventList = new ArrayList<>();
	
	public void addEventHandler(EventHandler EH1) {
		EventList.add(EH1);
		}
	
	public void click() {
		for(EventHandler s: EventList ) {
			s.actionPerformed();
		}
	}
	
}
