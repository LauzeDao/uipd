package ckone;

public interface EventHandler {
	
	public void actionPerformed();

		

}
