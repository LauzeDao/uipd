package ckone;

public class MyEventHandler2 extends MyEventHandler {

	@Override
	public void actionPerformed() {
		
		System.out.println("meh");
	}
	
}
